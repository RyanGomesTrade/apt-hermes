#!/usr/bin/env bash
# Funções compartilhadas pelos comandos hq-hermes-*.
# Só define funções: carregar com `source` não tem efeito colateral.

# Pacotes que só existem no Windows e quebram a instalação no Linux.
HQ_PACOTES_SO_WINDOWS="pywin32 pywin32-ctypes pypiwin32 wmi winshell"

# hq_filtrar_lock <entrada> <saida>
# Copia o lock removendo os pacotes exclusivos de Windows (nome exato, sem
# diferenciar maiúsculas) e convertendo CRLF para LF.
hq_filtrar_lock() {
    local entrada="$1" saida="$2"
    awk -v excluir="$HQ_PACOTES_SO_WINDOWS" '
        BEGIN { n = split(excluir, lista, " "); for (i = 1; i <= n; i++) fora[lista[i]] = 1 }
        {
            sub(/\r$/, "")
            nome = tolower($0)
            sub(/[[:space:]]*[=<>!~;\[].*$/, "", nome)
            if (!(nome in fora)) print
        }
    ' "$entrada" > "$saida"
}

# hq_validar_commit <sha>: 0 só para 40 caracteres hexadecimais minúsculos.
hq_validar_commit() {
    [[ "${1:-}" =~ ^[0-9a-f]{40}$ ]]
}

# hq_arquivo_config: caminho do arquivo de configuração do Hermes.
hq_arquivo_config() {
    printf '%s/caduceu/hermes.conf\n' "${XDG_CONFIG_HOME:-$HOME/.config}"
}

# hq_arquivo_config_sistema: configuração do Hermes pré-instalado (vem no pacote caduceu-hermes).
hq_arquivo_config_sistema() {
    printf '%s\n' "${HQ_CONFIG_SISTEMA:-/etc/caduceu/hermes.conf}"
}

# hq_ler_config: carrega a configuração (a do usuário; sem ela, a do sistema) e exporta HERMES_DIR.
hq_ler_config() {
    local arquivo
    arquivo="$(hq_arquivo_config)"
    [ -r "$arquivo" ] || arquivo="$(hq_arquivo_config_sistema)"
    if [ ! -r "$arquivo" ]; then
        printf 'hq: Hermes nao configurado. Rode antes: hq-hermes-setup\n' >&2
        return 1
    fi
    # shellcheck source=/dev/null
    . "$arquivo"
    export HERMES_DIR HERMES_COMMIT
}

# hq_refazer_ambiente <dir>: lock sem pacotes de Windows -> uv pip sync; depois npm ci.
# Devolve o status do primeiro passo que falhar. HQ_UV e HQ_NPM trocam os comandos (testes).
hq_refazer_ambiente() {
    local dir="$1"
    (
        cd "$dir" || exit 1
        # A main antiga do Hermes (antes de 18/10/2026) não tinha o lock; sem ele não há
        # ambiente reproduzível, então para com uma mensagem clara (código 3).
        if [ ! -f requirements-lock.txt ]; then
            printf 'hq: esta versão do Hermes não tem requirements-lock.txt em %s; ' "$dir" >&2
            printf 'atualize a main do GitHub para uma versão que tenha.\n' >&2
            exit 3
        fi
        mkdir -p .venv
        hq_filtrar_lock requirements-lock.txt .venv/requirements-linux.txt || exit $?
        "${HQ_UV:-uv}" pip sync --python .venv/bin/python .venv/requirements-linux.txt || exit $?
        "${HQ_NPM:-npm}" --prefix frontend ci || exit $?
    )
}

# hq_entrar_hermes: lê a configuração, confere o .venv e entra no diretório do Hermes.
hq_entrar_hermes() {
    hq_ler_config || return 1
    if [ ! -x "$HERMES_DIR/.venv/bin/python" ]; then
        printf 'hq: %s/.venv nao encontrado. Rode antes: hq-hermes-setup\n' "$HERMES_DIR" >&2
        return 1
    fi
    cd "$HERMES_DIR" || return 1
    # Equivale ao `activate` do venv: no Debian não existe `python` global
    # (só python3), e partes do Hermes chamam `python` pelo nome.
    export VIRTUAL_ENV="$HERMES_DIR/.venv"
    export PATH="$VIRTUAL_ENV/bin:$PATH"
}
