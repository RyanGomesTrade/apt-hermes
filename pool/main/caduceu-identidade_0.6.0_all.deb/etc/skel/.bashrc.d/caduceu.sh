# Prompt e boas-vindas do Caduceu OS. Carregado pelo ~/.bashrc.
# Cores ANSI do esquema "Caduceu" do terminal: 30 = tinta, 31 = alerta.
case $- in
    *i*) ;;
    *) return ;;
esac

PS1='\[\e]0;\u@\h: \w\a\]\[\e[30m\]\u@\h \w \[\e[31m\]\$\[\e[0m\] '

# Boas-vindas no primeiro terminal de cada sessão gráfica. O console de texto (o tty1 entra
# sozinho no modo live) e o SSH não mostram nem gastam a mensagem. O marcador fica no
# XDG_RUNTIME_DIR, um por sessão, porque as sessões do mesmo usuário dividem esse diretório.
# Para desligar: mkdir -p ~/.config/caduceu && touch ~/.config/caduceu/sem-boas-vindas
_caduceu_marca="${XDG_RUNTIME_DIR:-}/caduceu-boas-vindas-${XDG_SESSION_ID:-${DISPLAY:-}}"
if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] \
    && [ -n "${XDG_RUNTIME_DIR:-}" ] && [ -d "$XDG_RUNTIME_DIR" ] \
    && [ ! -e "$_caduceu_marca" ] \
    && [ ! -e "$HOME/.config/caduceu/sem-boas-vindas" ]; then
    : > "$_caduceu_marca"
    echo "Caduceu OS 0.6.0 — laboratório de pesquisa. Estado do sistema: hq-diagnostico"
fi
unset _caduceu_marca
