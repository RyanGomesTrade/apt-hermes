
# Caduceu OS: carrega os trechos de ~/.bashrc.d (prompt e boas-vindas).
for _caduceu_trecho in "$HOME"/.bashrc.d/*.sh; do
    [ -r "$_caduceu_trecho" ] && . "$_caduceu_trecho"
done
unset _caduceu_trecho
